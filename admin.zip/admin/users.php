<?php
session_start();
require_once __DIR__ . '/../HealthSystem.php';
// Page layout and CSS are included directly below.
// Shared layout for Admin and other staff pages.
function h($value) { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
function page_start($title, $role = 'admin') {
    $links = [
        'admin' => ['index.php'=>'Dashboard','users.php'=>'Users','residents.php'=>'Residents','medicines.php'=>'Medicines','reports.php'=>'Reports'],
        'bhw' => ['index.php'=>'Dashboard','residents.php'=>'Residents','consultations.php'=>'Consultations','vaccinations.php'=>'Vaccinations','maternal_child.php'=>'Maternal & Child'],
        'nurse' => ['index.php'=>'Dashboard','consultations.php'=>'Consultations','vaccinations.php'=>'Vaccinations','medicines.php'=>'Medicines','appointments.php'=>'Appointments'],
        'mho' => ['index.php'=>'Dashboard','reports.php'=>'Reports']
    ];
    $current = basename($_SERVER['SCRIPT_NAME'] ?? 'index.php');
    $username = h($_SESSION['USERNAME'] ?? ucfirst($role));
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'.h($title).' | Barangay Health</title>';
    echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><style>body{background:#f8f9fa;font-family:Arial,sans-serif;color:#183153}.navbar{background:#ffeb00;border-bottom:3px solid #123b70;padding:10px 20px}.navbar-brand{color:#123b70;font-weight:bold;font-size:18px;text-decoration:none}.sidebar{background:#123b70;min-height:calc(100vh - 71px);padding:25px 15px}.sidebar h5{color:#ffeb00;font-size:16px;margin-bottom:22px}.sidebar a{display:block;color:white;padding:12px 14px;text-decoration:none;border-radius:7px;margin-bottom:5px}.sidebar a:hover,.sidebar a.active{background:#ffeb00;color:#123b70;font-weight:bold}.content{padding:30px}.page-title{color:#123b70;font-weight:bold;margin-bottom:24px}.panel{background:white;border-radius:12px;padding:22px;margin-bottom:20px;box-shadow:0 2px 10px #00000012}.stat h2{color:#123b70;font-weight:bold}.btn-primary{background:#123b70;border-color:#123b70}.btn-primary:hover{background:#0c294e;border-color:#0c294e}.table thead{background:#123b70;color:white}.table thead th{background:#123b70;color:white}@media(max-width:767px){.sidebar{min-height:auto}.content{padding:18px}.navbar-brand{font-size:14px}}
</style></head><body>';
    echo '<nav class="navbar"><a class="navbar-brand d-flex align-items-center gap-2" href="index.php"><img src="../brgylogo.jpg" alt="Barangay logo" width="45" height="45" style="object-fit:contain"> Barangay Tawang Health System</a><span class="ms-auto me-3">'.$username.'</span><a class="btn btn-outline-primary btn-sm" href="../logout.php">Logout</a></nav>';
    echo '<div class="container-fluid"><div class="row"><aside class="col-md-3 col-lg-2 sidebar"><h5>'.h(strtoupper($role)).' PANEL</h5>';
    foreach (($links[$role] ?? $links['admin']) as $file=>$label) echo '<a class="'.($current===$file?'active':'').'" href="'.h($file).'">'.h($label).'</a>';
    echo '</aside><main class="col-md-9 col-lg-10 content"><h3 class="page-title">'.h($title).'</h3>';
}
function page_end() { echo '</main></div></div></body></html>'; }
function stat_card($title, $value) { echo '<div class="col-sm-6 col-xl-3 mb-3"><div class="panel stat"><div class="text-muted">'.h($title).'</div><h2>'.h($value).'</h2></div></div>'; }
function notice($message, $type='success') { if ($message !== '') echo '<div class="alert alert-'.($type==='danger'?'danger':'success').'">'.h($message).'</div>'; }
function table_show($rows, $columns) {
    echo '<div class="panel table-responsive"><table class="table table-striped table-hover"><thead><tr>';
    foreach ($columns as $heading) echo '<th>'.h($heading).'</th>';
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) { echo '<tr>'; foreach ($columns as $field=>$heading) echo '<td>'.h($row[$field] ?? '').'</td>'; echo '</tr>'; }
    if (!$rows) echo '<tr><td colspan="'.count($columns).'" class="text-center text-muted">No records found.</td></tr>';
    echo '</tbody></table></div>';
}

if (!isset($_SESSION['ID']) || ($_SESSION['ROLE'] ?? '') !== 'admin') { header('Location: ../login.php'); exit; }
$obj = new HealthSystem($pdo);
$message = ''; $error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { $error='Invalid form request.'; }
    else {
        try {
            if (isset($_POST['add_user'])) {
                $username = trim($_POST['username'] ?? ''); $password = $_POST['password'] ?? ''; $role = $_POST['role'] ?? '';
                if (!filter_var($username,FILTER_VALIDATE_EMAIL) || strlen($password)<8 || !in_array($role,['admin','bhw','nurse','mho','resident'],true)) throw new Exception('Enter a valid email, password of at least 8 characters, and role.');
                if (!$obj->register($username,$password,$role)) throw new Exception('Username already exists.');
                $message='User created.';
            } elseif (isset($_POST['update_status'])) {
                $id=(int)($_POST['user_id'] ?? 0); $status=$_POST['status'] ?? '';
                if (!in_array($status,['active','inactive'],true) || $id<=0) throw new Exception('Invalid status.');
                if ($id === (int)$_SESSION['ID'] && $status === 'inactive') throw new Exception('You cannot deactivate your own account.');
                $stmt=$pdo->prepare('UPDATE users SET status=? WHERE user_id=?'); $stmt->execute([$status,$id]); $message='Status updated.';
            }
        } catch (Exception $e) { $error=$e->getMessage(); }
    }
}
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
$users=$pdo->query('SELECT user_id,username,role,status FROM users ORDER BY user_id DESC')->fetchAll();
page_start('Manage Users','admin'); notice($message); notice($error,'danger'); ?>
<div class="panel"><h5>Add User</h5><form method="post" class="row g-3"><input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
<div class="col-md-4"><label>Email / Username</label><input class="form-control" type="email" name="username" required></div>
<div class="col-md-3"><label>Password</label><input class="form-control" type="password" name="password" minlength="8" required></div>
<div class="col-md-3"><label>Role</label><select class="form-select" name="role"><?php foreach(['resident','bhw','nurse','mho','admin'] as $r): ?><option value="<?= h($r) ?>"><?= h(strtoupper($r)) ?></option><?php endforeach; ?></select></div>
<div class="col-md-2 d-flex align-items-end"><button class="btn btn-primary w-100" name="add_user">Add User</button></div></form></div>
<div class="panel"><h5>User Accounts</h5><div class="table-responsive"><table class="table"><thead><tr><th>ID</th><th>Username</th><th>Role</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php foreach($users as $u): ?><tr><td><?= h($u['user_id']) ?></td><td><?= h($u['username']) ?></td><td><?= h($u['role']) ?></td><td><?= h($u['status']) ?></td><td><form method="post" class="d-flex gap-2"><input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>"><input type="hidden" name="user_id" value="<?= h($u['user_id']) ?>"><select name="status" class="form-select form-select-sm"><option value="active" <?= $u['status']==='active'?'selected':'' ?>>Active</option><option value="inactive" <?= $u['status']==='inactive'?'selected':'' ?>>Inactive</option></select><button class="btn btn-primary btn-sm" name="update_status">Save</button></form></td></tr><?php endforeach; ?>
</tbody></table></div></div><?php page_end();
