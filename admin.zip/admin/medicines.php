<?php
session_start();
require_once __DIR__ . '/../HealthSystem.php';
// Page layout and CSS are included directly below.
// Shared layout for Admin and other staff pages.
function h($value) { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
function page_start($title, $role = 'admin') {
    $links = [
        'admin' => ['index.php'=>'Dashboard','users.php'=>'Users','residents.php'=>'Residents','medicines.php'=>'Medicines','reports.php'=>'Reports'],
        'bhw' => ['index.php'=>'Dashboard','residents.php'=>'Residents','consultations.php'=>'Consultations','vaccinations.php'=>'Vaccinations','maternal_child.php'=>'Maternal & Child'],
        'nurse' => ['index.php'=>'Dashboard','consultations.php'=>'Consultations','vaccinations.php'=>'Vaccinations','medicines.php'=>'Medicines','appointments.php'=>'Appointments'],
        'mho' => ['index.php'=>'Dashboard','reports.php'=>'Reports']
    ];
    $current = basename($_SERVER['SCRIPT_NAME'] ?? 'index.php');
    $username = h($_SESSION['USERNAME'] ?? ucfirst($role));
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'.h($title).' | Barangay Health</title>';
    echo '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><style>body{background:#f8f9fa;font-family:Arial,sans-serif;color:#183153}.navbar{background:#ffeb00;border-bottom:3px solid #123b70;padding:10px 20px}.navbar-brand{color:#123b70;font-weight:bold;font-size:18px;text-decoration:none}.sidebar{background:#123b70;min-height:calc(100vh - 71px);padding:25px 15px}.sidebar h5{color:#ffeb00;font-size:16px;margin-bottom:22px}.sidebar a{display:block;color:white;padding:12px 14px;text-decoration:none;border-radius:7px;margin-bottom:5px}.sidebar a:hover,.sidebar a.active{background:#ffeb00;color:#123b70;font-weight:bold}.content{padding:30px}.page-title{color:#123b70;font-weight:bold;margin-bottom:24px}.panel{background:white;border-radius:12px;padding:22px;margin-bottom:20px;box-shadow:0 2px 10px #00000012}.stat h2{color:#123b70;font-weight:bold}.btn-primary{background:#123b70;border-color:#123b70}.btn-primary:hover{background:#0c294e;border-color:#0c294e}.table thead{background:#123b70;color:white}.table thead th{background:#123b70;color:white}@media(max-width:767px){.sidebar{min-height:auto}.content{padding:18px}.navbar-brand{font-size:14px}}
</style></head><body>';
    echo '<nav class="navbar"><a class="navbar-brand d-flex align-items-center gap-2" href="index.php"><img src="../brgylogo.jpg" alt="Barangay logo" width="45" height="45" style="object-fit:contain"> Barangay Tawang Health System</a><span class="ms-auto me-3">'.$username.'</span><a class="btn btn-outline-primary btn-sm" href="../logout.php">Logout</a></nav>';
    echo '<div class="container-fluid"><div class="row"><aside class="col-md-3 col-lg-2 sidebar"><h5>'.h(strtoupper($role)).' PANEL</h5>';
    foreach (($links[$role] ?? $links['admin']) as $file=>$label) echo '<a class="'.($current===$file?'active':'').'" href="'.h($file).'">'.h($label).'</a>';
    echo '</aside><main class="col-md-9 col-lg-10 content"><h3 class="page-title">'.h($title).'</h3>';
}
function page_end() { echo '</main></div></div></body></html>'; }
function stat_card($title, $value) { echo '<div class="col-sm-6 col-xl-3 mb-3"><div class="panel stat"><div class="text-muted">'.h($title).'</div><h2>'.h($value).'</h2></div></div>'; }
function notice($message, $type='success') { if ($message !== '') echo '<div class="alert alert-'.($type==='danger'?'danger':'success').'">'.h($message).'</div>'; }
function table_show($rows, $columns) {
    echo '<div class="panel table-responsive"><table class="table table-striped table-hover"><thead><tr>';
    foreach ($columns as $heading) echo '<th>'.h($heading).'</th>';
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) { echo '<tr>'; foreach ($columns as $field=>$heading) echo '<td>'.h($row[$field] ?? '').'</td>'; echo '</tr>'; }
    if (!$rows) echo '<tr><td colspan="'.count($columns).'" class="text-center text-muted">No records found.</td></tr>';
    echo '</tbody></table></div>';
}

if (!isset($_SESSION['ID']) || ($_SESSION['ROLE'] ?? '') !== 'admin') { header('Location: ../login.php'); exit; }
$obj = new HealthSystem($pdo);
$message=''; $error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) $error='Invalid form request.';
    else {
        try {
            $name=trim($_POST['medicine_name'] ?? ''); $unit=trim($_POST['unit'] ?? ''); $qty=filter_var($_POST['quantity'] ?? '',FILTER_VALIDATE_INT); $min=filter_var($_POST['minimum_stock'] ?? '',FILTER_VALIDATE_INT);
            $date=($_POST['expiration_date'] ?? '') ?: null;
            if ($name==='' || $unit==='' || $qty===false || $min===false || $qty<0 || $min<0 || ($date && !DateTime::createFromFormat('!Y-m-d',$date))) throw new Exception('Check the medicine details.');
            $obj->add_medicine($name,$unit,$qty,$min,$date); $message='Medicine added.';
        } catch (Exception $e) { $error=$e->getMessage(); }
    }
}
$_SESSION['csrf'] ??= bin2hex(random_bytes(32)); $rows=$obj->show_medicines();
page_start('Medicine Inventory','admin'); notice($message); notice($error,'danger'); ?>
<div class="panel"><h5>Add Medicine</h5><form method="post" class="row g-3"><input type="hidden" name="csrf" value="<?= h($_SESSION['csrf']) ?>">
<div class="col-md-4"><label>Medicine Name</label><input class="form-control" name="medicine_name" required></div><div class="col-md-2"><label>Unit</label><input class="form-control" name="unit" placeholder="tablet" required></div>
<div class="col-md-2"><label>Quantity</label><input class="form-control" type="number" min="0" name="quantity" required></div><div class="col-md-2"><label>Minimum Stock</label><input class="form-control" type="number" min="0" name="minimum_stock" value="10" required></div><div class="col-md-2"><label>Expiry Date</label><input class="form-control" type="date" name="expiration_date"></div>
<div class="col-12"><button class="btn btn-primary">Add Medicine</button></div></form></div>
<?php table_show($rows,['medicine_id'=>'ID','medicine_name'=>'Medicine','unit'=>'Unit','quantity'=>'Quantity','minimum_stock'=>'Minimum','expiration_date'=>'Expiry']); page_end();
